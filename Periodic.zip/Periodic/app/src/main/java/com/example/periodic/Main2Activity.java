package com.example.periodic;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Button button = (Button)findViewById(R.id.h);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main2Activity.this, showhydrogen.class);
                startActivity(intent);
            }
        });

        ImageView imageView = (ImageView) findViewById(R.id.iconh);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main2Activity.this,showhydrogen.class);
                startActivity(intent);
            }
        });

        Button button1 = (Button)findViewById(R.id.he);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main2Activity.this, showhelium.class);
                startActivity(intent);
            }
        });
        ImageView imageView1 = (ImageView) findViewById(R.id.iconhe);
        imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main2Activity.this,showhelium.class);
                startActivity(intent);
            }
        });
        Button button2 = (Button)findViewById(R.id.li);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main2Activity.this, showLithium.class);
                startActivity(intent);
            }
        });
        ImageView imageView2 = (ImageView) findViewById(R.id.iconli);
        imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main2Activity.this,showLithium.class);
                startActivity(intent);
            }
        });
        Button button3 = (Button)findViewById(R.id.be);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main2Activity.this, show_berylium.class);
                startActivity(intent);
            }
        });
        ImageView imageView3 = (ImageView) findViewById(R.id.iconbe);
        imageView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main2Activity.this,show_berylium.class);
                startActivity(intent);
            }
        });
        Button button4 = (Button)findViewById(R.id.c);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main2Activity.this, show_carbon.class);
                startActivity(intent);
            }
        });
        ImageView imageView4 = (ImageView) findViewById(R.id.iconc);
        imageView4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main2Activity.this,show_carbon.class);
                startActivity(intent);
            }
        });
        Button button5 = (Button)findViewById(R.id.n);
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main2Activity.this, show_berylium.class);
                startActivity(intent);
            }
        });
        ImageView imageView5 = (ImageView) findViewById(R.id.iconn);
        imageView5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main2Activity.this,show_berylium.class);
                startActivity(intent);
            }
        });
        Button button6 = (Button)findViewById(R.id.o);
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main2Activity.this, show_oxygen.class);
                startActivity(intent);
            }
        });
        ImageView imageView6 = (ImageView) findViewById(R.id.icono);
        imageView6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Main2Activity.this,show_oxygen.class);
                startActivity(intent);
            }
        });
    }
    }

