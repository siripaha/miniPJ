package com.example.periodic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class showhelium extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showhelium);

        Button buttona = (Button)findViewById(R.id.returnn);
        buttona.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(showhelium.this,showhydrogen.class);
                startActivity(intent);
                finish();
            }
        });
        Button buttonb = (Button)findViewById(R.id.webhee);
        buttonb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browerIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://th.wikipedia.org/wiki/ฮีเลียม\t\t\t\t\t\t\t\n"));
                startActivity(browerIntent);
            }
        });
        Button buttonc = (Button)findViewById(R.id.behrhium);
        buttonc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(showhelium.this,showhydrogen.class);
                startActivity(intent);
                finish();
            }
        });
        Button buttond = (Button)findViewById(R.id.nextlithium);
        buttond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(showhelium.this,showLithium.class);
                startActivity(intent);
                finish();
            }
        });

    }
}
