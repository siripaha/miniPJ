package com.example.periodic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class show_berylium extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_berylium);

        Button button34 = (Button)findViewById(R.id.retrun1);
        button34.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(show_berylium.this,showLithium.class);
                startActivity(intent);
                finish();
            }
        });
        Button button35 = (Button)findViewById(R.id.web1);
        button35.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browerIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://th.wikipedia.org/wiki/เบริลเลียม"));
                startActivity(browerIntent);
            }
        });
        Button button3 = (Button)findViewById(R.id.button7);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(show_berylium.this,showLithium.class);
                startActivity(intent);
                finish();
            }
        });
        Button button4 = (Button)findViewById(R.id.button6);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(show_berylium.this,show_boron.class);
                startActivity(intent);
                finish();
            }
        });

    }
}
