package com.example.periodic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class show_carbon extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_carbon);

        Button button39 = (Button)findViewById(R.id.button11);
        button39.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(show_carbon.this,show_boron.class);
                startActivity(intent);
                finish();
            }
        });
        Button button40 = (Button)findViewById(R.id.button10);
        button40.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browerIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://th.wikipedia.org/wiki/คาร์บอน\t\t\t\t\t\t\t\n"));
                startActivity(browerIntent);
            }
        });
        Button button41 = (Button)findViewById(R.id.button12);
        button41.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(show_carbon.this,show_boron.class);
                startActivity(intent);
                finish();
            }
        });
        Button button42 = (Button)findViewById(R.id.button13);
        button42.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(show_carbon.this,show_nitrogen.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
