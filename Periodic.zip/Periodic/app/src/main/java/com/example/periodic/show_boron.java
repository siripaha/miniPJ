package com.example.periodic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class show_boron extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_boron);

        Button button34 = (Button)findViewById(R.id.button3);
        button34.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(show_boron.this,show_berylium.class);
                startActivity(intent);
                finish();
            }
        });
        Button button35 = (Button)findViewById(R.id.button2);
        button35.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browerIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://th.wikipedia.org/wiki/โบรอน\t\t\t\t\t\t\t\n"));
                startActivity(browerIntent);
            }
        });
        Button button36 = (Button)findViewById(R.id.button9);
        button36.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(show_boron.this,show_berylium.class);
                startActivity(intent);
                finish();
            }
        });
        Button button37 = (Button)findViewById(R.id.button8);
        button37.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(show_boron.this,show_carbon.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
