package com.example.periodic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import static android.os.Build.VERSION_CODES.P;

public class showhydrogen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showhydrogen);

        Button button = (Button)findViewById(R.id.next);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(showhydrogen.this,showhelium.class);
                startActivity(intent);
                finish();
            }
        });
        Button button4 = (Button)findViewById(R.id.ic_keyboard_return);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(showhydrogen.this,Main2Activity.class);
                startActivity(intent);
            }
        });

            //Button button = (Button)findViewById(R.id.web);
            //Intent browerIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://th.wikipedia.org/wiki/ไฮโดรเจน\t\t\t\t\t\t\t\n"));
            //startActivity(browerIntent);

        Button button2 = (Button)findViewById(R.id.web);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browerIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://th.wikipedia.org/wiki/ไฮโดรเจน\t\t\t\t\t\t\t\n"));
                startActivity(browerIntent);
            }
        });
        }



}
