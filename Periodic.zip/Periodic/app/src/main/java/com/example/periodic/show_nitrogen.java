package com.example.periodic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class show_nitrogen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_nitrogen);

        Button button43 = (Button)findViewById(R.id.button15);
        button43.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(show_nitrogen.this,show_carbon.class);
                startActivity(intent);
                finish();
            }
        });
        Button button44 = (Button)findViewById(R.id.button14);
        button44.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browerIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://th.wikipedia.org/wiki/ไนโตรเจน\t\t\t\t\t\t\t\n"));
                startActivity(browerIntent);
            }
        });
        Button button45 = (Button)findViewById(R.id.button17);
        button45.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(show_nitrogen.this,show_carbon.class);
                startActivity(intent);
                finish();
            }
        });
        Button button46 = (Button)findViewById(R.id.button16);
        button46.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(show_nitrogen.this,show_oxygen.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
