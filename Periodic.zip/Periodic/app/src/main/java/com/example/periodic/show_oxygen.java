package com.example.periodic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class show_oxygen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_oxygen);

        Button button = (Button)findViewById(R.id.button19);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(show_oxygen.this,show_nitrogen.class);
                startActivity(intent);
                finish();
            }
        });
        Button button5 = (Button)findViewById(R.id.button18);
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browerIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://th.wikipedia.org/wiki/ออกซิเจน\t\t\t\t\t\t\t\n"));
                startActivity(browerIntent);
            }
        });
        Button button1 = (Button)findViewById(R.id.button21);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(show_oxygen.this,show_nitrogen.class);
                startActivity(intent);
                finish();
            }
        });
        Button button2 = (Button)findViewById(R.id.button20);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(show_oxygen.this,show_oxygen.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
